import React from 'react';

export default function BellSound() {
  // Placeholder for audio hook or <audio /> element
  return <div className="text-sm text-gray-500">Bell sound component</div>;
}
