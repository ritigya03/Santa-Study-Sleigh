import React from "react";

export default function Ornament({ color = "red" }: { color?: string }) {
  return <div className={`h-6 w-6 rounded-full bg-${color}-500`} />;
}
