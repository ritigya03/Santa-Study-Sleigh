export type AnimationState = 'TREE' | 'EXPLODE'
