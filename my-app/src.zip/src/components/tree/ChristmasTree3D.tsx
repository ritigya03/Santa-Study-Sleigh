import React from "react";

export default function ChristmasTree3D() {
  return (
    <div className="w-full rounded-lg border p-4">
      <div className="text-center text-sm text-gray-500">
        3D tree placeholder (GLTF/Three.js)
      </div>
    </div>
  );
}
