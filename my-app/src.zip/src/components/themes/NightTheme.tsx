import React from "react";

export default function NightTheme() {
  return <div className="p-4">Night theme placeholder</div>;
}
