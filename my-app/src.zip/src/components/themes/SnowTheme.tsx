import React from "react";

export default function SnowTheme() {
  return <div className="p-4">Snow theme placeholder</div>;
}
