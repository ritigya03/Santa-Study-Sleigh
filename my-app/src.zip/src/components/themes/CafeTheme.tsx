import React from "react";

export default function CafeTheme() {
  return <div className="p-4">Cafe theme placeholder</div>;
}
